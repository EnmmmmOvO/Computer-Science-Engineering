class ab{ 
  
  
  
  public static void main(String[] args) {
    
    
    boolean flag;
    int x;
    flag  = false;
    x =0;
    
    
    while(!flag){
      x = x+1;
      if(x == 5){
        flag = true;
      }
    }
    
    
  }
  
  
}