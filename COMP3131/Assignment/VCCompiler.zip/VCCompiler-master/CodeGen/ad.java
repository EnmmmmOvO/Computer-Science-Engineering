class ad{ 
  
  
  
  public static void main(String[] args) {
    
    int[] ar = new int[10];
    int i;
    
    for(i = 0;i<11;i = i+1){
      ar[i] = i;
      
    }
    
    
  }
  
  
}