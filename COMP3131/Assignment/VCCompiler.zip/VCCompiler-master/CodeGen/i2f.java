class i2f{
  
  
  
  
  
 public static void main(String[] args) {
   
   int x;
   float y;
   float z;
   
   x = 3;
   y = (float) 3.2;
   
   z = x  + y;
   
   
   
 }
  
  
}