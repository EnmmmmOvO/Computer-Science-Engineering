class neg{ 
  
  
  public float temp(){
    float c;
    c = (float)-5.1;
    return -c;
  }
  public static void main(String[] args) {
    
    int x;
    int y;
    int z;
    y = 5;
    x = -42;
    z = x + y;
    if(z==-42){
      z = 0;
    }
    
    
    
    
   
    
  }
  
  
}