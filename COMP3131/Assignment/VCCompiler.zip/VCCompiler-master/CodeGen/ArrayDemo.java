class ArrayDemo {

  
//  public int[] test(int[] x){
//    return x;
//  }
  
    public static void main(String[] args) {
        // declares an array of integers
       // int[] anArray;

        // allocates memory for 10 integers
      
        double[] anArray = new double[10];
      
        //boolean[] array2 = new boolean[2];
           
        // initialize first element
        anArray[0] = 100.1;
        
        double x;
        x = anArray[0]+1.4;
        //array2[1] = false;
        // initialize second element
 
    }
} 