class aa{ 
  
  
  
  public static void main(String[] args) {
    int sum;
    int i;
    sum = 0;
     i = 0;
    
//    for(i = 0; i<11; i = i + 1){
//      sum = sum + i;
//      if(i == 2 ){
//        break;
//      }else{
//        i = 3;
//        continue;
//      }
//      
//    }
    
    while(i  < 10 ){
      System.out.println(i);
      i = i +1;
      continue;
      //i = i+1;
      
      
      
    }
    

  }

}