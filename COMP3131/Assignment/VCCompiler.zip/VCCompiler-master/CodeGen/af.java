class af{ 
  
  
  
  public static void main(String[] args) {
    
    boolean[] ar = {true,false,true};
    boolean i;
    i = ar[2];
    
    //for(i = 0;i<ar.length;i = i+1){
    // System.out.println(ar[i]);
      
   // }
    
    
  }
  
  
}