class ac{ 
  
  
  
  public static void main(String[] args) {
    
    
    //boolean flag;
    int x;
    //flag  = false;
    x =0;
    
    
    while(!(x>4)){
      x = x+1;
      if(x == 5){
        x = 6;
      }
    }
    
    
  }
  
  
}