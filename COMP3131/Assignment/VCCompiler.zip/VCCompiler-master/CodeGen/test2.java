float f[2];
int main() {
putFloatLn(f[0]);
putFloatLn(f[1]);
return 0;
}