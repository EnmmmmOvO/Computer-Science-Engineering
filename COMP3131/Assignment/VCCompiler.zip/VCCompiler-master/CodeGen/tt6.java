class tt6{ 
 
  
  
  public static void main(String[] args) {
    int a;
    int b;
    int c; 
    int d = c = b= a = 1;
    
    
  }
}