class loopTest{ 
  
  
  
  public static void main(String[] args) {
    

    int i = 0;
    for(; i < 10; i = i + 1){
                  System.out.println(i);
            continue;

    }

    
  }
  
  
}