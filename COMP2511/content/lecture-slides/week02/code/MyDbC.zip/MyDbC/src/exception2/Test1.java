package exception2;

import java.io.IOException;

public class Test1 {

	public static void main(String[] args)   {
		

		ListOfNumbers ln = new ListOfNumbers();
		ln.writeList();



		System.out.println("####  End of the program ..... ");

	}

}
