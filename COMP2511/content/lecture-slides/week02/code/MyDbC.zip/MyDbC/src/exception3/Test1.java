package exception3;

public class Test1 {

	public static void main(String[] args)   {
		

		ListOfNumbers ln = new ListOfNumbers();
		ln.writeList();

		System.out.println("####  End of the program ..... ");

	}

}
