package MethodsStaticVsInstance;

public class A {

	public void f1() {
		System.out.println("From f1 in A (instance method)");
	}

	public static void f2() {
		System.out.println("From f2 in A (static method)");
	}
	
	
}
