/** Demo Example for COMP2511 
 * @author ashesh
 */

package composite.typesafe;

public interface Component {
	
	public String nameString();
	public double calculateCost();
	
}
