/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package pizza;

public class MargheritaPizza extends Pizza {


	@Override
	int getPrice() {
		// TODO Auto-generated method stub
		return 10;
	}

}
