/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package pizza;

public abstract class Topping {

	public abstract float getWeightUsed();
	
}


