/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package pizza;

public class CheeseTopping extends Topping {

	
	public float getWeightUsed() {
		
		return 5;
	}
}
