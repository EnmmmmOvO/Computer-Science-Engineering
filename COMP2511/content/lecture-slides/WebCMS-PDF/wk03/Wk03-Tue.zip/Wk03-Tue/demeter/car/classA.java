/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package car;

public class classA {

	public void doSomething(Car car) {
		
		String pcode = car.getOwner().getAddress().getPostcode();
		
	}
	
	
}
