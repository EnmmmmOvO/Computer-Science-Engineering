package exception3;

class MyException extends Exception {

    public MyException(String message){
        
        super( message );

    }
    
}