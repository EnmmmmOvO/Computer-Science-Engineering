/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package TestPackage2;

import Shapes.Circle;

public class A extends Circle {

	public A() {
		r = 23; 
		//x = 12; 
	}
	
}
