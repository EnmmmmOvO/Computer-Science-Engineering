package example;

public class Friend {

	public void N() {
		// do something
	}
}
