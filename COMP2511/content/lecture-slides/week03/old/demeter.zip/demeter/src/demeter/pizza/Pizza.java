/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 */

package demeter.pizza;

public abstract class Pizza {

	
	abstract int getPrice();
	
}
