package headfirst.iterator.dinermerger;

public interface Iterator<T> {
	boolean hasNext();
	T next();
}
