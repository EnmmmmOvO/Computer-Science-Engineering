
This example is from the following web site:
https://refactoring.guru/design-patterns/visitor/java/example#example-0--visitor-XMLExportVisitor-java
