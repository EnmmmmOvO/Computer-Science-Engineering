package car;


public interface CarElementVisitable {
	
	 void accept(CarElementVisitor visitor);
}


