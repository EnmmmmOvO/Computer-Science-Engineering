package factorypattern;

public interface GUIFactory {
	
	public Button    getButton();
	public CheckBox  getCheckBox();


	
	
}
