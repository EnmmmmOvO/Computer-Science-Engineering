package factorypattern;

public interface Button {

	public void setLabel(String labelText);
	public void click();
	
}
