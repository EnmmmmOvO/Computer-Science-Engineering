README

This example is adapted from the following web site:

https://refactoring.guru/design-patterns/builder/java/example#lang-features

