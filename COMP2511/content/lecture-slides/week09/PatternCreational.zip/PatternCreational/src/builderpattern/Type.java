package builderpattern;

public enum Type {
    CITY_CAR, SPORTS_CAR, SUV
}

