
From 
https://docs.oracle.com/javase/8/javafx/visual-effects-tutorial/basics.htm

