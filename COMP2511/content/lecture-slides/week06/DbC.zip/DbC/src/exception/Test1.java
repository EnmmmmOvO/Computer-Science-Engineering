package exception;

public class Test1 {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		try {
			ListOfNumbers ln = new ListOfNumbers();
			ln.writeList();
		}
		catch(MyException1 e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
	}

}
