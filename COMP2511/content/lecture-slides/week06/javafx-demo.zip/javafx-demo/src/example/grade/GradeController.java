package example.grade;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class GradeController {

	@FXML
	private Button displayGrade;

	@FXML
	private TextField marks;

	@FXML
	private Label grade;

	@FXML
	private CheckBox capitalChk;

	private BooleanProperty capitalDisplay;

	public GradeController() {
		capitalDisplay = new SimpleBooleanProperty();
	}

	@FXML
	public void initialize() {
		capitalDisplay.bindBidirectional(capitalChk.selectedProperty());
		capitalDisplay.setValue(true);

	}
	
	@FXML
	void handleDisplayGradeBtn(ActionEvent event) {
		displayGrade();
	}

	@FXML
	void handleCapitalChk(ActionEvent event) {
		displayGrade();
	}

	@FXML
	private void displayGrade() {

		int marksInt = 0;
		String gradeStr = ""; 
				
		try {
			if(marks.getText().length() > 0) {
				marksInt = Integer.parseInt( marks.getText());
				gradeStr = GradeModel.getGrade(marksInt);
			}
		}
		catch (Exception e){
			gradeStr = "Invalid marks!";
		}

		if (capitalDisplay.getValue()) {
			gradeStr = gradeStr.toUpperCase();
		}

		/**
		 * if (capitalChk.isSelected()) { gradeStr = gradeStr.toUpperCase(); }
		 */

		grade.setText(gradeStr);
	}

	
}
