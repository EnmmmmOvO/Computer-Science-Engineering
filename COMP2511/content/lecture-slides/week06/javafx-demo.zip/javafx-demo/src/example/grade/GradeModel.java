package example.grade;

public class GradeModel {

	public static String getGrade(int marks) {
		String msg;
		if (marks >= 0 && marks <= 100) {
			if (marks >= 50) {
				msg = "Pass";
			} else {
				msg = "Fail";
			}
		} else {
			msg = "Invalid marks!";
		}

		return msg;
	}
	
	
}
