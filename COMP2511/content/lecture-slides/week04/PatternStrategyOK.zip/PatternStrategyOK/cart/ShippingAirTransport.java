package cart;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

import java.util.ArrayList;

public class ShippingAirTransport implements ShippingOption {

	@Override
	public double calculateCharges(ArrayList<Item> list) {
		// TODO Auto-generated method stub
		return 0;
	}

}
