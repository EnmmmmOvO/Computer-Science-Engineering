package cart;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public class CardPayment implements PaymentOption {

	@Override
	public boolean charge(double amt) {
		// TODO Auto-generated method stub
		return false;
	}



}
