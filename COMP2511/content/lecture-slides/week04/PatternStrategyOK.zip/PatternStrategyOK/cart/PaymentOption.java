package cart;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public interface PaymentOption {
	
	 public boolean charge(double amt);
	 
}
