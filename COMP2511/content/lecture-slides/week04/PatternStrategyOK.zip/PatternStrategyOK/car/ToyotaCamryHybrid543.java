package car;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public class ToyotaCamryHybrid543 extends Car {

	public ToyotaCamryHybrid543 () {
		
		super(new EngineHybrid(), new BrakeABS());
	}
	

}
