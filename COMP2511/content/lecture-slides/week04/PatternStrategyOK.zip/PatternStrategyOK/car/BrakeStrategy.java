package car;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public interface BrakeStrategy {

		public void apply();
		
}
