package car;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public class EngineNormal implements EngineType {
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Running engine is Normal ");		
	}

}
