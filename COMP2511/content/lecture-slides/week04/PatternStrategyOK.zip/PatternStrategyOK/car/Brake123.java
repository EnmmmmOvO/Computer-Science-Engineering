
package car;

public class Brake123  implements BrakeStrategy{

	@Override
	public void apply() {
		System.out.println("Braking style is Brake123 ");
		
	}
    
}