package car;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public class EngineElectric implements EngineType {

	@Override
	public void run() {
		System.out.println("Running engine is Electric ");		
		
	}
	

}
