package car;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public class TeslaSUV123 extends Car {

	public TeslaSUV123 () {
		
		super(new EngineElectric(), new BrakeABS());
	}
	
	
}
