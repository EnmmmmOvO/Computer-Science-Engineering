package WeatherV2;
/** Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * @author ashesh
 */

public interface ObserverHygrometer {
	
	public void update(SubjectHygrometer obj);
	
}

