#include <cstddef>
#include <cstdint>
#include <vector>

#ifndef Q1_HPP
#define Q1_HPP

namespace q1 {
    using map = std::vector<std::vector<char>>;

    enum class move : uint8_t {
        NN,
        SS,
        WW,
        EE,
        NW,
        NE,
        SW,
        SE,
    };

    class style {};

    class detailed_style : public style {};

    auto at(const map &mp, int x, int y) -> char;
    auto at(map &mp, int x, int y) -> char&;

    auto make_map(const std::vector<move> & path, const style &styler) -> map;

} // namespace q1

#endif // Q1_HPP
