#ifndef Q2_HPP
#define Q2_HPP

namespace q2 {
    template <typename T, auto C, auto D>
    class scope_guard {

    };
}

#endif // Q2_HPP
