#include <catch2/catch.hpp>

#include <q2/q2.hpp>

TEST_CASE("comparing two smart lists") {
	// uncomment this when code is written

	// auto l = q2::smart_list<int>();
	// l.push_back(5);
	// l.push_back(6);

	// auto m = q2::smart_list<int>();
	// m.push_back(5);
	// m.push_back(6);

	// REQUIRE(l == m);
}
