#include <fstream>
#include <iomanip>
#include <iostream>

#include <q1/q1.hpp>

namespace q1 {
	auto run_calculator(std::vector<std::string> const& input) -> std::vector<std::string> const {
		(void)input; // Remove this line
		auto output = std::vector<std::string>{};
		return output;
	}
} // namespace q1
