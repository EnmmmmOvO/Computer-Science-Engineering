#ifndef Q1_HPP
#define Q1_HPP

namespace q2 {
    template <typename T>
    class smart_list {};

    template <typename T>
    class very_smart_list {};
}

#endif // Q2_HPP
